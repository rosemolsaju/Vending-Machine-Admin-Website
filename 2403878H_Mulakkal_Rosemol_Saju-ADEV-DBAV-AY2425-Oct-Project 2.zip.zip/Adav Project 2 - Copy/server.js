const express = require('express');
const db = require('./db-connections'); // Ensure this is the correct path to your database connection
const cors = require('cors');
const app = express();

// Middleware to handle JSON request bodies
app.use(express.json());

// This allows cross-origin requests (useful for front-end and back-end running on different ports during development)
app.use(cors());

// Serve static files (like HTML, CSS, JS) from the current directory (or another directory if you prefer)
app.use(express.static(__dirname));  // This will serve files from the current project folder

// ---- Items Endpoints ----

// Endpoint to get all items
app.route('/items').get((req, res) => {
    const sql = 'SELECT * FROM item';

    db.query(sql, (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(result);
    });
});

// Endpoint to get an item by ID
app.route('/items/:id').get((req, res) => {
    const itemId = req.params.id;
    const sql = 'SELECT * FROM item WHERE item_id = ?';

    db.query(sql, [itemId], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (result.length === 0) {
            return res.status(404).json({ error: 'Item not found' });
        }
        res.json(result[0]);
    });
});

// Endpoint to add a new item
app.route('/items').post((req, res) => {
    const { item_name, item_cost, item_quantity, availability, item_image } = req.body;

    if (!item_name || !item_cost || !item_quantity || availability === undefined || !item_image) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    const sql = 'INSERT INTO item (item_name, item_cost, item_quantity, availability, item_image) VALUES (?, ?, ?, ?, ?)';
    db.query(sql, [item_name, item_cost, item_quantity, availability, item_image], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ message: 'Item added successfully', id: result.insertId });
    });
});


// Endpoint to update an item
app.route('/items/:id').put((req, res) => {
    const itemId = req.params.id;
    const { item_name, item_cost, item_quantity, availability, item_image } = req.body;

    if (!item_name || !item_cost || !item_quantity || availability === undefined || !item_image) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    const sql = 'UPDATE item SET item_name = ?, item_cost = ?, item_quantity = ?, availability = ?, item_image = ? WHERE item_id = ?';
    db.query(sql, [item_name, item_cost, item_quantity, availability, item_image, itemId], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Item not found' });
        }

        res.json({ message: 'Item updated successfully' });
    });
});

// Endpoint to delete an item
app.route('/items/:id').delete((req, res) => {
    const itemId = req.params.id;
    const sql = 'DELETE FROM item WHERE item_id = ?';

    db.query(sql, [itemId], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Item not found' });
        }

        res.json({ message: 'Item deleted successfully' });
    });
});

// ---- Locations Endpoints ----

// Endpoint to get all locations
app.route('/locations').get((req, res) => {
  const sql = 'SELECT * FROM location';  // Table name should match exactly
  db.query(sql, (err, result) => {
      if (err) {
          return res.status(500).json({ error: err.message });
      }
      res.json(result);
  });
});

// Endpoint to get a location by ID
app.route('/locations/:location_id').get((req, res) => {
  const locationId = req.params.location_id;
  const sql = 'SELECT * FROM location WHERE location_id = ?';  // Use location_id here
  db.query(sql, [locationId], (err, result) => {
      if (err) {
          return res.status(500).json({ error: err.message });
      }
      if (result.length === 0) {
          return res.status(404).json({ error: 'Location not found' });
      }
      res.json(result[0]);
  });
});

// Endpoint to add a new location
app.route('/locations').post((req, res) => {
  const { school, block, floor } = req.body;
  if (!school || !block || !floor) {
      return res.status(400).json({ error: 'Missing required fields' });
  }
  const sql = 'INSERT INTO location (school, block, floor) VALUES (?, ?, ?)';
  db.query(sql, [school, block, floor], (err, result) => {
      if (err) {
          return res.status(500).json({ error: err.message });
      }
      res.status(201).json({ message: 'Location added successfully', id: result.insertId });
  });
});

// Endpoint to update a location
// Endpoint to update a location
app.route('/locations/:location_id').put((req, res) => {
  const locationId = req.params.location_id;  // location_id here
  const { school, block, floor } = req.body;

  // Ensure that block and floor are numbers
  if (isNaN(block) || isNaN(floor)) {
      return res.status(400).json({ error: 'Block and Floor must be valid numbers' });
  }

  if (!school || !block || !floor) {
      return res.status(400).json({ error: 'Missing required fields' });
  }

  const sql = 'UPDATE location SET school = ?, block = ?, floor = ? WHERE location_id = ?';
  db.query(sql, [school, block, floor, locationId], (err, result) => {
      if (err) {
          return res.status(500).json({ error: err.message });
      }

      if (result.affectedRows === 0) {
          return res.status(404).json({ error: 'Location not found' });
      }

      res.json({ message: 'Location updated successfully' });
  });
});


// Endpoint to delete a location
app.route('/locations/:id').delete((req, res) => {
  const locationId = req.params.id;
  const sql = 'DELETE FROM location WHERE location_id = ?';  // Ensure 'location_id' is used, not 'id'

  db.query(sql, [locationId], (err, result) => {
      if (err) {
          return res.status(500).json({ error: err.message });
      }

      if (result.affectedRows === 0) {
          return res.status(404).json({ error: 'Location not found' });
      }

      res.json({ message: 'Location deleted successfully' });
  });
});


// POST route to add a vending machine
app.post('/vending_machine', (req, res) => {
    const { school, block, floor, vendor_name, status } = req.body;

    // Check if all required fields are provided
    if (!school || !block || !floor || !vendor_name || !status) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    // SQL query to insert data into the correct table in the correct database
    const sql = 'INSERT INTO vending_machine.vending_machines (school, block, floor, vendor_name, status) VALUES (?, ?, ?, ?, ?)';
    db.query(sql, [school, block, floor, vendor_name, status], (err, result) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Failed to add vending machine' });
        }
        res.status(201).json({ message: 'Vending machine added successfully', id: result.insertId });
    });
});


// Endpoint to fetch all vending machine summary data
app.get('/vending_machine_summary', (req, res) => {
    const sql = 'SELECT * FROM vending_machine_summary'; // Ensure this table name is correct
  
    db.query(sql, (err, results) => {
      if (err) {
        console.error('Error fetching data:', err);
        return res.status(500).json({ error: 'Failed to fetch data from the database' });
      }
      if (results.length === 0) {
        return res.status(404).json({ message: 'No vending machine summaries found' });
      }
      res.json({ message: 'Data fetched successfully', results });
    });
  });
  
 // Endpoint to add a new vending machine summary
app.post('/vending_machine_summary', (req, res) => {
    try {
      const { school, block, floor, status_name, payment_methods, image_url } = req.body;
  
      if (!school || !block || !floor || !status_name || !payment_methods || !image_url) {
        return res.status(400).json({ error: 'Missing required fields' });
      }
  
      const sql = 'INSERT INTO vending_machine_summary (school, block, floor, status_name, payment_methods, image_url) VALUES (?, ?, ?, ?, ?, ?)';
      db.query(sql, [school, block, floor, status_name, payment_methods, image_url], (err, result) => {
        if (err) {
          console.error('Error inserting data:', err);
          return res.status(500).json({ error: 'Failed to add vending machine summary' });
        }
        res.status(201).json({ message: 'Vending machine summary added successfully', id: result.insertId });
      });
    } catch (err) {
      console.error('Error processing request:', err);
      return res.status(500).json({ error: 'Internal server error' });
    }
  });


  app.get('/vending_machine_summary', (req, res) => {
    const query = `
      SELECT vms.vending_machine_id, vms.block, vms.floor, vms.payment_methods, vms.image_url,
             i.item_name, i.price, i.quantity, i.item_image, i.availability
      FROM vending_machine_summary vms
      LEFT JOIN items i ON vms.vending_machine_id = i.summary_id
    `;
  
    db.query(query, (err, results) => {
      if (err) {
        return res.status(500).json({ error: 'Internal Server Error' });
      }
  
      const formattedResults = results.reduce((acc, row) => {
        let vendingMachine = acc.find(vm => vm.vending_machine_id === row.vending_machine_id);
        if (!vendingMachine) {
          vendingMachine = {
            vending_machine_id: row.vending_machine_id,
            block: row.block,
            floor: row.floor,
            payment_methods: row.payment_methods,
            image_url: row.image_url,
            items: []
          };
          acc.push(vendingMachine);
        }
  
        if (row.item_name) {
          vendingMachine.items.push({
            item_name: row.item_name,
            price: row.price,
            quantity: row.quantity,
            item_image: row.item_image,
            availability: row.availability
          });
        }
  
        return acc;
      }, []);
  
      res.json({ results: formattedResults });
    });
  });



// Endpoint to fetch all vmitems
app.get('/vmitems', (req, res) => {
  const sql = 'SELECT * FROM vmitems'; // Correct table name `vmitems`

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching data:', err);
      return res.status(500).json({ error: 'Failed to fetch data from the database' });
    }
    if (results.length === 0) {
      return res.status(404).json({ message: 'No items found' });
    }
    res.json({ message: 'Data fetched successfully', results });
  });
});


app.post('/vmitems', (req, res) => {
  const { item_name, price, quantity, availability, item_image, summary_id } = req.body;

  // Ensure that the summary_id is provided
  if (!item_name || !price || !quantity || availability === undefined || !item_image || !summary_id) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const sql = 'INSERT INTO vmitems (item_name, price, quantity, availability, item_image, summary_id) VALUES (?, ?, ?, ?, ?, ?)';
  
  db.query(sql, [item_name, price, quantity, availability, item_image, summary_id], (err, result) => {
    if (err) {
      console.error('Error inserting data:', err);
      return res.status(500).json({ error: 'Failed to add item' });
    }
    res.status(201).json({ message: 'Item added successfully', id: result.insertId });
  });
});

app.put('/vmitems/:id', (req, res) => {
  const itemId = req.params.id;  // Get the item_id from the URL parameter
  const { item_name, price, quantity, availability, item_image } = req.body;

  // Check for missing fields
  if (!item_name || !price || !quantity || availability === undefined || !item_image) {
      return res.status(400).json({ error: 'Missing required fields' });
  }

  const sql = `
      UPDATE vmitems
      SET item_name = ?, price = ?, quantity = ?, availability = ?, item_image = ?
      WHERE item_id = ?
  `;

  db.query(sql, [item_name, price, quantity, availability, item_image, itemId], (err, result) => {
      if (err) {
          console.error('Error updating item:', err);
          return res.status(500).json({ error: 'Failed to update item' });
      }

      if (result.affectedRows === 0) {
          return res.status(404).json({ error: 'Item not found with the provided item_id' });
      }

      res.json({ message: 'Item updated successfully' });
  });
});



// Endpoint to delete an item
app.delete('/vmitems/:id', (req, res) => {
  const itemId = req.params.id;
  const sql = 'DELETE FROM vmitems WHERE item_id = ?';

  db.query(sql, [itemId], (err, result) => {
    if (err) {
      console.error('Error deleting data:', err);
      return res.status(500).json({ error: 'Failed to delete item' });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Item not found' });
    }

    res.json({ message: 'Item deleted successfully' });
  });
});


// Endpoint to fetch items for a given summary_id
app.get('/vending_machine_summary/:summary_id', (req, res) => {
  const summaryId = req.params.summary_id; // Get summary_id from the URL

  // SQL query to get item details based on summary_id
  const query = `
      SELECT 
          vmitems.item_name,
          vmitems.price,
          vmitems.quantity,
          vmitems.availability,
          vmitems.item_image
      FROM 
          vmitems
      JOIN 
          vending_machine_summary summary ON vmitems.summary_id = summary.summary_id
      WHERE 
          summary.summary_id = ?;
  `;

  // Execute the query
  db.query(query, [summaryId], (err, results) => {
      if (err) {
          console.error('Error fetching items:', err);
          return res.status(500).json({ error: 'Internal Server Error' });
      }

      if (results.length === 0) {
          return res.status(404).json({ message: 'No items found for this summary_id' });
      }

      // Return the results in JSON format
      res.json({ items: results });
  });
});



// Route to fetch total revenue
app.get('/total-revenue', (req, res) => {
  const sql = 'SELECT SUM(item_cost * item_quantity) AS total_revenue FROM item';
  db.query(sql, (err, result) => {
      if (err) {
          return res.status(500).json({ error: err.message });
      }
      res.json(result[0]); // Send total revenue as JSON
  });
});

// Route to fetch top purchase item
app.get('/top-purchase', (req, res) => {
  const sql = 'SELECT item_name, (item_cost * item_quantity) AS revenue FROM item ORDER BY revenue DESC LIMIT 1';
  db.query(sql, (err, result) => {
      if (err) {
          return res.status(500).json({ error: err.message });
      }
      res.json(result[0]); // Send top purchase item as JSON
  });
});






// Start the server on port 8080
app.listen(8080, () => {
    console.log('Server running on port 8080');
});


