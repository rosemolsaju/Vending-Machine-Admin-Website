const mysql = require('mysql2');

// To create connection to the MySQL database
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',          // The MySQL username
  password: 'adev',      // The MySQL password for them to access
  database: 'vending_machine'  // The name of the database im taking from
});

// To test the connection if working.
db.connect((err) => {
  if (err) {
    console.error('Error connecting to the database:', err.stack);
    return;
  }
  console.log('Connected to DB');
});

module.exports = db;
