// Wait until the DOM content is loaded to ensure everything is ready before we start
document.addEventListener("DOMContentLoaded", function () {
    // Check if we're on the items page or locations page
    if (window.location.pathname.includes("items.html")) {
        // Fetching items data and populating the items table
        fetchItems();
    } else if (window.location.pathname.includes("locations.html")) {
        // Fetching locations data and populating the locations table
        fetchLocations();
    }
});

// Fetch items from the backend API and populate the items table
function fetchItems() {
    fetch('http://127.0.0.1:8080/items')
        .then(response => response.json()) // Parse the JSON response
        .then(items => {
            console.log(items); // Log the data to the console to verify it's coming in
            const itemsTable = document.getElementById("itemsTable").getElementsByTagName('tbody')[0];
            itemsTable.innerHTML = ''; // Clear previous table rows

            // Loop through each item and add it to the table
            items.forEach(item => {
                const row = itemsTable.insertRow();
                row.innerHTML = `
                    <td>${item.item_name}</td>
                    <td>${item.item_cost}</td>
                    <td>${item.item_quantity}</td>
                    <td><img src="${item.item_image}" alt="Item Image" style="width: 100px; height: auto;"></td>
                    <td>
                        <button class="btn" onclick="editItem(${item.item_id})">Edit</button>
                        <button class="btn" onclick="deleteItem(${item.item_id})">Delete</button>
                    </td>
                `;
            });
        })
        .catch(error => {
            console.error('Error fetching items:', error);
        });
}


// Fetch locations from the backend API and populate the locations table
// Fetch locations from the backend API and populate the locations table
// Fetch locations from the backend API and populate the locations table
function fetchLocations() {
    fetch('http://127.0.0.1:8080/locations')
        .then(response => response.json()) // Parse the JSON response
        .then(locations => {
            console.log(locations); // Log the data to the console to verify it's coming in
            const locationsTable = document.getElementById("locationsTable").getElementsByTagName('tbody')[0];
            locationsTable.innerHTML = ''; // Clear previous table rows

            // Loop through each location and add it to the table
            locations.forEach(location => {
                const row = locationsTable.insertRow();
                row.innerHTML = `
                    <td>${location.school}</td>
                    <td>${location.block}</td>
                    <td>${location.floor}</td>
                    <td>
                        <button class="btn" onclick="editLocation(${location.location_id})">Edit</button>
                        <button class="btn" onclick="deleteLocation(${location.location_id})">Delete</button>
                    </td>
                `;
            });
        })
        .catch(error => {
            console.error('Error fetching locations:', error);
        });
}



// Delete an item by ID - This sends a DELETE request to the backend API
function deleteItem(itemId) {
    const confirmDelete = confirm("Are you sure you want to delete this item?");
    
    if (confirmDelete) {
        fetch(`http://127.0.0.1:8080/items/${itemId}`, {
            method: 'DELETE',
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Item deleted successfully') {
                alert("Item deleted successfully");
                fetchItems();  // Refresh the table view without the deleted item
            }
        })
        .catch(error => { 
            console.error('Error deleting item:', error); 
        });
    }
}

// Delete a location by ID - This sends a DELETE request to the backend API
// Delete a location by ID - This sends a DELETE request to the backend API
function deleteLocation(locationId) {
    const confirmDelete = confirm("Are you sure you want to delete this location?");
    
    if (confirmDelete) {
        console.log('Location ID:', locationId);  // Add this line to check the ID
        fetch(`http://127.0.0.1:8080/locations/${locationId}`, {
            method: 'DELETE',
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Location deleted successfully') {
                alert("Location deleted successfully");
                fetchLocations();  // Refresh the table view without the deleted location
            }
        })
        .catch(error => { 
            console.error('Error deleting location:', error); 
        });
    }
}


// Edit an item - This sends a PUT request to update the item on the backend
function editItem(itemId) {
    const name = prompt("Enter new item name:");
    const price = prompt("Enter new price:");
    const quantity = prompt("Enter new quantity:");
    const availability = prompt("Enter new availability (true/false):");
    const image = prompt("Enter new image URL:");

    if (name && price && quantity && availability && image) {
        const itemData = {
            item_name: name,
            item_cost: price,
            item_quantity: quantity,
            availability: availability,
            item_image: image
        };

        fetch(`http://127.0.0.1:8080/items/${itemId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(itemData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Item updated successfully') {
                alert("Item updated successfully");
                fetchItems();
            } else {
                alert("Failed to update item: " + data.error);
            }
        })
        .catch(error => console.error('Error updating item:', error));
    } else {
        alert('Please fill in all fields');
    }
}

// Edit a location - This sends a PUT request to update the location on the backend
// Edit a location - This sends a PUT request to update the location on the backend
function editLocation(locationId) {
    const school = prompt("Enter new school:");
    const block = prompt("Enter new block (must be a number):");
    const floor = prompt("Enter new floor (must be a number):");

    // Check if the values entered are valid
    if (school && block && floor) {
        const blockNumber = Number(block);  // Convert block to a number
        const floorNumber = Number(floor);  // Convert floor to a number

        // Ensure block and floor are valid numbers
        if (isNaN(blockNumber) || isNaN(floorNumber)) {
            alert("Block and Floor must be valid numbers.");
            return;
        }

        const locationData = {
            school: school,
            block: blockNumber,
            floor: floorNumber
        };

        console.log("Editing location with data:", locationData); // Debugging log

        // Sending the PUT request to update the location
        fetch(`http://127.0.0.1:8080/locations/${locationId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(locationData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Location updated successfully') {
                alert("Location updated successfully");
                fetchLocations();  // Refresh the table view after update
            } else {
                alert("Failed to update location: " + data.error);
            }
        })
        .catch(error => {
            console.error('Error updating location:', error);
        });
    } else {
        alert("Please fill in all fields.");
    }
}


// Add a new item - This sends a POST request to add the new item to the backend
function addItem() {
    const name = prompt("Enter item name:");
    const price = prompt("Enter item price:");
    const quantity = prompt("Enter item quantity:");
    const availability = (prompt("Enter availability (true/false):").toLowerCase() === "true");
    let image = prompt("Enter item image URL:");

    if (name && price && quantity && availability !== undefined && image) {
        if (!isValidImageURL(image)) {
            alert('Please enter a valid image URL.');
            return;
        }

        const newItem = {
            item_name: name,
            item_cost: price,
            item_quantity: quantity,
            availability: availability,
            item_image: image
        };

        fetch('http://127.0.0.1:8080/items', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newItem)
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Item added successfully') {
                alert("Item added successfully");
                fetchItems();  // Refresh the table view with the new item
            }
        })
        .catch(error => console.error('Error adding item:', error));
    } else {
        alert('Please fill in all fields');
    }
}



// Add a new location - This sends a POST request to add the new location to the backend
// Add a new location - This sends a POST request to add the new location to the backend
function addLocation() {
    const school = prompt("Enter school:");
    const block = prompt("Enter block:");
    const floor = prompt("Enter floor:");

    if (school && block && floor) {
        const newLocation = {
            school: school,
            block: block,
            floor: floor
        };

        fetch('http://127.0.0.1:8080/locations', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newLocation)
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Location added successfully') {
                alert("Location added successfully");
                fetchLocations();  // Refresh the table view with the new location
            }
        })
        .catch(error => console.error('Error adding location:', error));
    } else {
        alert('Please fill in all fields');
    }
}

// to check if url is valid

function isValidImageURL(url) {
    return(url.match(/\.(jpeg|jpg|gif|png)$/) != null);
}

function addItem() {
    const name = prompt("Enter item name:");
    const price = prompt("Enter item price:");
    const quantity = prompt("Enter item quantity:");
    const availability = prompt("Enter availability (true/false):");
    let image = prompt("Enter item image URL:");

    if (name && price && quantity && availability && image) {
        if (!isValidImageURL(image)) {
            alert('Please enter a valid image URL.');
            return;
        }
        const newItem = {
            item_name: name,
            item_cost: price,
            item_quantity: quantity,
            availability: availability,
            item_image: image
        };

        fetch('http://127.0.0.1:8080/items', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newItem)
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Item added successfully') {
                alert("Item added successfully");
                fetchItems();
            }
        })
        .catch(error => console.error('Error adding item:', error));
    } else {
        alert('Please fill in all fields');
    }
}

// Handle vending machine registration
function registerVendingMachine() {
    const school = document.getElementById('school').value;
    const block = document.getElementById('block').value;
    const floor = document.getElementById('floor').value;
    const vendor_name = document.getElementById('vendor_name').value;
    const status = document.getElementById('status').value;

    // Validate that all required fields are filled
    if (!school || !block || !floor || !vendor_name || !status) {
        alert('Please fill in all fields');
        return;
    }

    const vendingMachineData = {
        school: school,
        block: block,
        floor: floor,
        vendor_name: vendor_name,
        status: status
    };

    // Send the data to the backend API
    fetch('http://localhost:8080/vending_machine', { // Your API endpoint
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(vendingMachineData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === 'Vending machine added successfully') {
            alert('Vending machine added successfully');
            document.getElementById('registrationForm').reset(); // Reset the form after successful submission
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error registering vending machine:', error);
        alert('There was an error registering the vending machine.');
    });
}


// Function to search through the table content
function searchTable() {
    // Get the value of the search bar and convert it to lowercase for case-insensitive search
    const query = document.getElementById('searchBar').value.toLowerCase();
    
    // Get all the rows in both the itemsTable and locationsTable
    const rows = document.querySelectorAll("#itemsTable tbody tr, #locationsTable tbody tr");

    // Loop through each row
    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        
        // Join all the text content of each cell in the row, and convert it to lowercase
        const rowText = Array.from(cells).map(cell => cell.textContent.toLowerCase()).join(' ');

        // If the row contains the search query, display it. Otherwise, hide it.
        if (rowText.includes(query)) {
            row.style.display = '';  // Show row
        } else {
            row.style.display = 'none';  // Hide row
        }
    });
}

// Add event listener to the search bar to call the searchTable function on input
document.getElementById('searchBar').addEventListener('input', searchTable);

// Function to sort the items by price (lowest to highest or highest to lowest)
function sortByPrice() {
    const sortOption = document.getElementById('sortByPrice').value;  // Get the selected option
    const rows = Array.from(document.querySelectorAll("#itemsTable tbody tr"));  // Get all rows

    rows.sort((rowA, rowB) => {
        const priceA = parseFloat(rowA.querySelector('td:nth-child(2)').textContent);  // Extract price from rowA
        const priceB = parseFloat(rowB.querySelector('td:nth-child(2)').textContent);  // Extract price from rowB

        if (sortOption === 'lowest') {
            return priceA - priceB;  // Sort from lowest to highest
        } else if (sortOption === 'highest') {
            return priceB - priceA;  // Sort from highest to lowest
        }
    });

    // Re-attach the rows to the table after sorting
    const tbody = document.querySelector('#itemsTable tbody');
    tbody.innerHTML = '';  // Clear existing rows
    rows.forEach(row => tbody.appendChild(row));  // Append sorted rows
}

// Function to sort the items alphabetically
function sortByName() {
    const sortOption = document.getElementById('sortByName').value;  // Get the selected option
    const rows = Array.from(document.querySelectorAll("#itemsTable tbody tr"));  // Get all rows

    rows.sort((rowA, rowB) => {
        const nameA = rowA.querySelector('td:nth-child(1)').textContent.toLowerCase();  // Extract name from rowA
        const nameB = rowB.querySelector('td:nth-child(1)').textContent.toLowerCase();  // Extract name from rowB

        if (sortOption === 'alphabetical') {
            return nameA.localeCompare(nameB);  // Sort alphabetically
        } else if (sortOption === 'reverse') {
            return nameB.localeCompare(nameA);  // Sort reverse alphabetically
        }
    });

    // Re-attach the rows to the table after sorting
    const tbody = document.querySelector('#itemsTable tbody');
    tbody.innerHTML = '';  // Clear existing rows
    rows.forEach(row => tbody.appendChild(row));  // Append sorted rows
}

// Add event listeners for sorting options
document.getElementById('sortByPrice').addEventListener('change', sortByPrice);
document.getElementById('sortByName').addEventListener('change', sortByName);



